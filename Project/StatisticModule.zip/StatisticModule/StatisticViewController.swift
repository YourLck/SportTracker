//
//  StatisticViewController.swift
//  My_Nofirst_Try
//
//  Created by Nikita Nemtsu on 09.10.2022.
//

import UIKit

class StatisticViewController: UIViewController {
    
    private let statisticLabel: UILabel = {
        let label = UILabel()
        label.text = "STATISTIC"
        label.textColor = .specialBlack
        label.font = .robotoMedium24()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let exercisesLabel: UILabel = {
        let label = UILabel()
        label.text = "Exercises"
        label.textColor = .specialLightBrown
        label.font = .robotoMedium14()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    
    private let tableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .none
       // tableView.separatorStyle = .none
        tableView.bounces = false
        tableView.delaysContentTouches = false
        tableView.showsVerticalScrollIndicator = false
        
        return tableView
    }()
    
    private let idTableViewStat = "idTableViewStat"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupViews()
        setConstraints()
        setDelegates()
        
    }
    
    private func setupViews() {
        view.backgroundColor = .specialBackground
        view.addSubview(statisticLabel)
        view.addSubview(exercisesLabel)
        view.addSubview(tableView)
        tableView.register(StatisticViewCell.self, forCellReuseIdentifier: idTableViewStat)
    }
    private func setDelegates() {
        tableView.delegate = self
        tableView.dataSource = self
    }
}

// MARK: - StatisticViewController

extension StatisticViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: idTableViewStat, for: indexPath) as?
                StatisticViewCell else {
            return UITableViewCell()
        }
        
        return cell
    }
}

extension  StatisticViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        100
    }
    
}

//MARK: - setConstraints
extension StatisticViewController {
    

    private func setConstraints() {
        NSLayoutConstraint.activate([
            statisticLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
            statisticLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statisticLabel.heightAnchor.constraint(equalToConstant: 24),
            
            exercisesLabel.topAnchor.constraint(equalTo: statisticLabel.bottomAnchor, constant: 75),
            exercisesLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            
            tableView.topAnchor.constraint(equalTo: exercisesLabel.bottomAnchor, constant: 0),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 0)
        ])
    }
    
}
