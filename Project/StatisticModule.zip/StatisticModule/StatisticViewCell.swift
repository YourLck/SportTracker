//
//  StatisticViewCell.swift
//  My_Nofirst_Try
//
//  Created by Nikita Nemtsu on 10.10.2022.
//

import UIKit

class StatisticViewCell: UITableViewCell {
    
    private let exerciseName: UILabel = {
        let label = UILabel()
        label.text = "Push Ups"
        label.textColor = .specialBlack
        label.font = .robotoMedium22()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let statisticRepsLabel: UILabel = {
        let label = UILabel()
        label.text = "Before: 16"
        label.textColor = .specialLightBrown
        label.font = .robotoMedium14()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let statisticSetsLabel: UILabel = {
        let label = UILabel()
        label.text = "Now: 20"
        label.textColor = .specialLightBrown
        label.font = .robotoMedium14()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    private let statisticSetCounter: UILabel = {
       let label = UILabel()
        label.text = "+2"
        label.textColor = .specialDarkGreen
        label.font = .robotoMedium22()
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    var statisticStackView = UIStackView()
    
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupViews()
        setConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        addSubview(exerciseName)
//        addSubview(statisticSetCounter)
        
        statisticStackView = UIStackView(arrangedSubviews: [statisticRepsLabel, statisticSetsLabel], spacing: 15)
        
        addSubview(statisticStackView)
    }
}

extension StatisticViewCell {
    
    private func setConstraints() {
        NSLayoutConstraint.activate([
            exerciseName.topAnchor.constraint(equalTo: topAnchor, constant: 5),
            exerciseName.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            exerciseName.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
//            exerciseName.heightAnchor.constraint(equalToConstant: 30),
            
            statisticStackView.topAnchor.constraint(equalTo: exerciseName.bottomAnchor, constant: 5),
            statisticStackView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            statisticStackView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            statisticStackView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -20),
            
//            statisticSetCounter.centerYAnchor.constraint(equalTo: centerYAnchor),
//            statisticStackView.leadingAnchor.constraint(equalTo: exerciseName.trailingAnchor, constant: 5),
//            statisticStackView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -5)
        
        
        ])
        
    }
}
